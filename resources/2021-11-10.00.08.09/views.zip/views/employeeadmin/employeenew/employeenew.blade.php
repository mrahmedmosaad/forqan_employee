@extends('layouts.app')

@section('content')
<div class="  container-fluid ">
    <div class="row justify-content-center " style="height: 1400px">


@livewire('employeenewwire')


    </div>
</div>

@endsection


