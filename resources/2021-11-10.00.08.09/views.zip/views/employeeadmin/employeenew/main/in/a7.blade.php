{{-- بيانات المؤهل --}}
<div class="container-fluid text-justify" dir="rtl">
  <div class="card bg-light mb-0">
    <div class="card-header p-1"> بيانات المؤهل
    </div>
    <div class="card-body">


      @include('employeeadmin.employeenew.main.mainqualifytable')



















 