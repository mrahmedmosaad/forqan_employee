year
job
jobdiv
job_division
school
stage
 
job_status
jobstartdate
jobfinishdate
notesjob

jobfile1
jobfile2
$item->jobyear
$item->job
$item->jobdiv
$item->job_division
$item->school
$item->stage
$item->job_status
 
$item->jobstartdate
$item->jobfinishdate
$item->notesjob