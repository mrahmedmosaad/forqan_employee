<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">


    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    
        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
    
        <title>{{ config('app.name', 'Laravel') }}</title>
    
        <!-- Scripts -->
        <script src="{{ asset('js/app.js') }}" defer></script>
        {{-- <script src="{{ asset('js/toastr.min.js') }}" defer></script> --}}
    
        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" rel="stylesheet">

        <!-- Styles -->
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        {{-- <link href="{{ asset('css/toastr.min.css') }}" rel="stylesheet"/> --}}
        @livewireStyles
        {{-- @toastr_css --}}
        <style>
            .breaking-news , .badge{
                 color: rgb(157, 255, 0);
                 text-shadow: 1px 2px rgb(58, 58, 59);
             }
             .rtl{direction:rtl!important;}
     .ltr{direction:ltr!important;}
       
       
       
       </style>
<style>
    .dropbtn {
      background-color: #04AA6D;
      color: white;
      padding: 16px;
      font-size: 16px;
      border: none;
    }
    
    .dropdown {
      position: relative;
      display: inline-block;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #f1f1f1;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
    }
    
    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }
    
    .dropdown-content a:hover {background-color: #ddd;}
    
    .dropdown:hover .dropdown-content {display: block;}
    
    .dropdown:hover .dropbtn {background-color: #3e8e41;}
    </style>

<style>
    svg:hover{
        cursor: pointer;
        fill-opacity: 0.4;
        fill: #093079;
    }
       svg:active{
        cursor: pointer;
        fill-opacity: 0.1;
        fill: #223fc4;
    }     svg{
            width: 33px;
    }
    .svgsm:hover{
        cursor: pointer;
        fill-opacity: 0.4;
        fill: #093079;
    }
    .svgsm:active{
        cursor: pointer;
        fill-opacity: 0.1;
        fill: #223fc4;
    }     svg{
            width: 30px;
    }
    
.svgsm{
     width: 24px ; 
    }
.svgvsm:hover{
        cursor: pointer;
        fill-opacity: 0.4;
        fill: #094fd1;
    }
    .svgvsm:active{
        cursor: pointer;
        fill-opacity: 0.1;
        fill: #162a85;
    
     }
.svgvsm{
     width: 15px ; 
    }
    /* .icoview{
        background: url('/icon/view.svg') no-repeat;
    } */
</style>







<style>
    .form-input {
      position: relative;
      font-family: "Source Sans Pro", sans-serif;
      font-weight: 600;
      width: 100%;
      text-align: center;
      /* min-width:   25px; */
      height: 40px;
      border: none;
      padding: 0 4px;
      box-shadow: none;
      outline: none;
      -webkit-transition: all .2s ease;
         -moz-transition: all .2s ease;
          -ms-transition: all .2s ease;
           -o-transition: all .2s ease;
              transition: all .2s ease;
    }
    .form-input.round {
      border-radius: 20px;
    }
    .form-input.basic {
      border: 1px solid rgba(0, 0, 0, .15);
    }
    .form-input.basic:hover {
      border-color: rgba(0, 0, 0, .35);
      box-shadow: 0 0 5px rgba(0, 0, 0, .2);
    }
    .form-input.basic:focus {
      border-color: #4285F4;
      box-shadow: 0 0 10px rgba(66, 133, 244, .5);
    
    
    }
      input:focus{
        border-color: #4285F4;
      box-shadow: 0 0 10px rgba(66, 133, 244, .5);
      }
      }
      input:hover{
        border-color: #4285F4;
      box-shadow: 0 0 10px rgba(66, 133, 244, .5) !important ;
      }    
      form-control:focus{
        border-color: #4285F4;
      box-shadow: 0 0 10px rgba(66, 133, 244, .5);
      }
    
    
    
    
    
      .spantext 
    {
        border: solid 1px black;
    }
     
    .form-control:focus,
    textarea:focus,
    select:focus,
input[type="text"]:focus,
/* input[type="select"]:focus, */
input[type="password"]:focus,
input[type="datetime"]:focus,
input[type="datetime-local"]:focus,
input[type="date"]:focus,
input[type="month"]:focus,
input[type="time"]:focus,
input[type="week"]:focus,
input[type="number"]:focus,
input[type="email"]:focus,
input[type="url"]:focus,
input[type="search"]:focus,
input[type="tel"]:focus,
input[type="color"]:focus,
.uneditable-input:focus {   
  border-color: rgba(133, 104, 239, 0.8);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(104, 147, 239, 0.6);
  outline: 0 none;
}

.form-control:hover,
textarea:hover,
    select:hover,
input[type="text"]:hover,
/* input[type="select"]:hover, */
input[type="password"]:hover,
input[type="datetime"]:hover,
input[type="datetime-local"]:hover,
input[type="date"]:hover,
input[type="month"]:hover,
input[type="time"]:hover,
input[type="week"]:hover,
input[type="number"]:hover,
input[type="email"]:hover,
input[type="url"]:hover,
input[type="search"]:hover,
input[type="tel"]:hover,
input[type="color"]:hover,
.uneditable-input:hover {   
  /* border-color: rgba(7, 151, 156, 0.712); */
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(104, 178, 239, 0.6);
  outline: 0 none;
}

.noborder{
    padding: 0;
border: none;
background: none;
}



    
    </style>

{{-- search --}}
<style>
    * {
      box-sizing: border-box;
    }
    
    body {
      font: 16px Arial;  
    }
    
    /*the container must be positioned relative:*/
    .autocomplete {
      position: relative;
      display: inline-block;
    }
    
    input {
      border: 1px solid transparent;
      background-color: #f1f1f1;
      padding: 10px;
      font-size: 16px;
    }
    
    input[type=text] {
      background-color: #f1f1f1;
      width: 100%;
    }
    
    input[type=submit] {
      background-color: DodgerBlue;
      color: #fff;
      cursor: pointer;
    }
    
    .autocomplete-items {
      position: absolute;
      border: 1px solid #d4d4d4;
      border-bottom: none;
      border-top: none;
      z-index: 99;
      /*position the autocomplete items to be the same width as the container:*/
      top: 100%;
      left: 0;
      right: 0;
    }
    
    .autocomplete-items div {
      padding: 10px;
      cursor: pointer;
      background-color: #fff; 
      border-bottom: 1px solid #d4d4d4; 
    }
    
    /*when hovering an item:*/
    .autocomplete-items div:hover {
      background-color: #e9e9e9; 
    }
    
    /*when navigating through the items using the arrow keys:*/
    .autocomplete-active {
      background-color: DodgerBlue !important; 
      color: #ffffff; 
    }
    </style>
{{-- search --}}


    </head>





<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel') }}
                </a>
                <div class="bg-danger w-25">

                    @yield('statusme')
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @guest
                            @if (Route::has('login'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                                </li>
                            @endif

                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }}
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
    </div>
    @livewireScripts
    {{-- @jquery
    @toastr_js
    @toastr_render --}}
    <script>
        // return a promise
function copyToClipboard(textToCopy) {
    // navigator clipboard api needs a secure context (https)
    if (navigator.clipboard && window.isSecureContext) {
        // navigator clipboard api method'
        return navigator.clipboard.writeText(textToCopy);
    } else {
        // text area method
        let textArea = document.createElement("textarea");
        textArea.value = textToCopy;
        // make the textarea out of viewport
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        textArea.style.top = "-999999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        return new Promise((res, rej) => {
            // here the magic happens
            document.execCommand('copy') ? res() : rej();
            textArea.remove();
            alert("Copied!");
        });
    }
}
        </script>



<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10">
</script>
 
<x-livewire-alert::scripts />
{{-- 

<script>
    $(document).ready(function() {
        $('#sidebarCollapse').on('click', function() {
            $('#sidebar').toggleClass('active');
        });
    });
    
</script>
@if (session()->has('success'))
<script>
toastr.success("{!! session()->get('success')!!}");
</script>
@endif


<script>
    window.addEventListener('alert', event => { 
                 toastr[event.detail.type](event.detail.message, 
                 event.detail.title ?? ''), toastr.options = {
                        "closeButton": true,
                        "progressBar": true,
                    }
                });
    </script> --}}

</body>
</html>
