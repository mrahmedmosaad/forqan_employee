<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 18.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg fill="red" style="width:22px"  version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 63 80.5" enable-background="new 0 0 63 80.5" xml:space="preserve">
<g>
	<path  d="M1.3,19.3L1.3,19.3L4.6,22v52.2c0,2.6,2.1,4.6,4.6,4.6h44.1c2.6,0,4.6-2.1,4.6-4.6V22l3.3-2.8h0v-4.6H1.3
		V19.3z M41.8,26.5h5.6v44.9h-5.6V26.5z M28.5,26.5h5.6v44.9h-5.6V26.5z M15.2,26.5h5.6v44.9h-5.6V26.5z"/>
	<path fill="#4E4F50" d="M60.3,8.1H40.8V3.5c0-1-0.8-1.9-1.9-1.9H23.7c-1,0-1.9,0.8-1.9,1.9v4.6H2.3c-0.6,0-1.1,0.5-1.1,1.1v3.6
		h60.2V9.2C61.4,8.6,60.9,8.1,60.3,8.1z M37.3,7h-12V5.7c0-0.3,0.3-0.6,0.6-0.6h10.8c0.3,0,0.6,0.3,0.6,0.6V7z"/>
</g>
</svg>
