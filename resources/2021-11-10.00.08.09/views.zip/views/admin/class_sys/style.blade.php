 
      <style>
         /* body{
          /* background-image: url('math.png'); */
          /* width: 200px; */
          background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center;
  /* filter: alpha(Opacity=95); */
opacity: 0.95;
        } */
      
*{
    /* font-family: "Open Sans Regular", "Helvetica", "Arial", sans-serif; */
    font-family: Arial, Helvetica, sans-serif;
   /* font-family: "Helvetica", "Arial", sans-serif; */
    /*text-shadow:
        0.07em 0 black,
        0 0.07em black,
        -0.07em 0 black,
        0 -0.07em black; */
}
    .normal {
  width: 100%;
  height: 100%;
  background-color:rgba(5, 5, 5, 0.527); 
  color: rgb(184, 220, 255);
  box-shadow: inset 0 2px 20px #90918e;
  /* box-shadow: 0 10px 10px -5px; */
  text-align: center;
  font-size: 16px;
  /* animation: mymove 5s infinite; */
  /* line-height: 200px; */
  /* box-shadow: 0 1px 4px rgba(0, 0, 0, .3),
              -23px 0 20px -23px rgba(0, 0, 0, .8),
              23px 0 20px -23px rgba(0, 0, 0, .8),
              inset 0 0 40px rgba(0, 0, 0, .1);
  */
}
.li {
  position: relative;
  float: left;
  width: 170px;
  height:110px;
  margin: 2px;
  padding: 1px 1px;
  list-style: none;
}
body
{
  font-family: Arial, Helvetica, sans-serif;
    /* font-family: 'Helvetica', 'Arial', sans-serif; */
    /* color: #444444; */
    font-size: 9pt;
    /* background-color: #FAFAFA; */
}


</style>

<style>
  /* Tooltip container */
  .tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black; /* If you want dots under the hoverable text */
  }
  
  /* Tooltip text */
  .tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    padding: 5px 0;
    border-radius: 6px;
   
    /* Position the tooltip text - see examples below! */
    position: absolute;
    z-index: 1;
  }
  
  /* Show the tooltip text when you mouse over the tooltip container */
  .tooltip:hover .tooltiptext {
    visibility: visible;
  }

.me1{
  font-size: 14px;
    border: none;
    border-radius: 2px;
    /* background-color: #007704;
    color: #FAFAFA; */
    transition-duration: 0.2s;
    /* text-shadow: 2px 2px 4px #000000; */
    /* box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); */
    /* box-shadow: 0 10px 10px -5px; */


    -webkit-box-shadow: 0 15px 10px #777;
  -moz-box-shadow: 0 15px 10px #777;
  box-shadow: 0 15px 10px #777;





    
    /* -webkit-box-shadow: 0 15px 10px #777;
  -moz-box-shadow: 0 15px 10px #777;
  box-shadow: 0 15px 10px #777;
  -webkit-transform: rotate(-3deg);
  -moz-transform: rotate(-3deg);
  -o-transform: rotate(-3deg);
  -ms-transform: rotate(-3deg);
  transform: rotate(-3deg); */






}
.me1:hover{
    background-color: #52b9f5; /* Green */
  /* color: white; */
  /* box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19); */
  box-shadow: 0 0 3px 1px blue;


  /* -webkit-transform: rotate(-3deg);
  -moz-transform: rotate(-3deg);
  -o-transform: rotate(-3deg);
  -ms-transform: rotate(-3deg);
  transform: rotate(-3deg); */

  }
  .me1:active{
    background-color: #b0ffb3; /* Green */
  
  /* box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19); */
  box-shadow: 0 0 10px 5px blue;
  }





  .me2{
  font-size: 14px;
    border: none;
    border-radius: 2px;
    /* background-color: #007704;
    color: #FAFAFA; */
    transition-duration: 0.2s;
    /* text-shadow: 2px 2px 4px #000000; */
    /* box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); */
    /* box-shadow: 0 10px 10px -5px; */


    -webkit-box-shadow: 0 15px 10px #777;
  -moz-box-shadow: 0 15px 10px #777;
  box-shadow: 0 15px 10px #777;





    
    /* -webkit-box-shadow: 0 15px 10px #777;
  -moz-box-shadow: 0 15px 10px #777;
  box-shadow: 0 15px 10px #777;
  -webkit-transform: rotate(-3deg);
  -moz-transform: rotate(-3deg);
  -o-transform: rotate(-3deg);
  -ms-transform: rotate(-3deg);
  transform: rotate(-3deg); */






}
.me2:active{
    background-color: #4CAF50; /* Green */
  /* color: white; */
  /* box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19); */
  box-shadow: 0 0 3px 1px blue;


  /* -webkit-transform: rotate(-3deg);
  -moz-transform: rotate(-3deg);
  -o-transform: rotate(-3deg);
  -ms-transform: rotate(-3deg);
  transform: rotate(-3deg); */

  }
  .me2:hover{
    background-color: #b0ffb3; /* Green */
  
  /* box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19); */
  box-shadow: 0 0 10px 5px blue;
  }

  .me3{
    /* background-color: #b0ffb3; Green */
  
  /* box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19); */
  box-shadow: 0 0 10px 5px blue;
  }

  .bgb{
    background-color: black;  
  
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
  /* box-shadow: 0 0 10px 5px blue; */
  }
  input[type=button] {
    font-size: 14px;
    border: none;
    border-radius: 2px;
    background-color: #007704;
    color: #FAFAFA;
    transition-duration: 0.2s;
    /* text-shadow: 2px 2px 4px #000000; */
    /* box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); */
    /* box-shadow: 0 10px 10px -5px; */


    -webkit-box-shadow: 0 15px 10px #777;
  -moz-box-shadow: 0 15px 10px #777;
  box-shadow: 0 15px 10px #777;





    
    /* -webkit-box-shadow: 0 15px 10px #777;
  -moz-box-shadow: 0 15px 10px #777;
  box-shadow: 0 15px 10px #777;
  -webkit-transform: rotate(-3deg);
  -moz-transform: rotate(-3deg);
  -o-transform: rotate(-3deg);
  -ms-transform: rotate(-3deg);
  transform: rotate(-3deg); */






  }

  input[type=button]:hover{
    background-color: #4CAF50; /* Green */
  color: white;
  /* box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19); */
  box-shadow: 0 0 3px 1px blue;


  /* -webkit-transform: rotate(-3deg);
  -moz-transform: rotate(-3deg);
  -o-transform: rotate(-3deg);
  -ms-transform: rotate(-3deg);
  transform: rotate(-3deg); */

  }

  svg:hover{
    background-color: white;
  }
 input[type=button]:active{
    background-color: #b0ffb3; /* Green */
  
  /* box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19); */
  box-shadow: 0 0 10px 5px blue;
  }


  .box1{
    -webkit-box-shadow: 0 15px 10px #777;
  -moz-box-shadow: 0 15px 10px #777;
  box-shadow: 0 15px 10px #777;
  -webkit-transform: rotate(-3deg);
  -moz-transform: rotate(-3deg);
  -o-transform: rotate(-3deg);
  -ms-transform: rotate(-3deg);
  transform: rotate(-3deg);
  }
.box2{
  -webkit-box-shadow: 0 35px 20px #777;
  -moz-box-shadow: 0 35px 20px #777;
  box-shadow: 0 35px 20px #777;
  -webkit-transform: rotate(-8deg);
  -moz-transform: rotate(-8deg);
  -o-transform: rotate(-8deg);
  -ms-transform: rotate(-8deg);
  transform: rotate(-8deg);
}
  </style>



<style>
 


.fixed-down2{
text-align: left;
text-shadow: #444444;

  /* background-color: #40a6ff; */
  /* opacity: 0.85; */
  padding: 10px;
  color: rgba(255, 255, 255, 0.9);
  position: fixed;
  /* bottom: 0; */
  bottom: 45px;
  left: 0;
  right: 0;
  /* z-index: -1; */

}
.anim-borderaaaaa{
  padding: 1px;
  /* animation-name: down2animation; */
  /* animation-duration: 1s;
  animation-iteration-count: infinite; */
  animation-name: animborder;
  animation-duration: 2s;
  animation-direction: reverse;  
    animation-iteration-count: infinite;
}

@keyframes animborder {
  /* 0%   {background-color:red; left:0px; top:0px;}
  25%  {background-color:yellow; left:200px; top:0px;}
  50%  {background-color:blue; left:200px; top:200px;}
  75%  {background-color:green; left:0px; top:200px;}
  100% {background-color:red; left:0px; top:0px;} */
 
/* 0%   {box-shadow: 0  0 5px 10px blue;} */
  /* 25%  {box-shadow: 0  0 5px 10px blue;} */
  50%  {box-shadow: 0  0 3px  5px blue;}
  /* 75%  {box-shadow: 0  0 1px  2px blue;} */
  /* 100% {box-shadow: 0  0 10px 15px blue;} */
 
  


}
/* ------------------------------------------------------------------ */

.anim-border2aaaaa{
  padding: 1px;
  /* animation-name: down2animation; */
  /* animation-duration: 1s;
  animation-iteration-count: infinite; */
  animation-name: animborder2;
  animation-duration: 5s;
  animation-direction: reverse;  
    animation-iteration-count: infinite;
}

@keyframes animborder2 {
  /* 0%   {background-color:red; left:0px; top:0px;}
  25%  {background-color:yellow; left:200px; top:0px;}
  50%  {background-color:blue; left:200px; top:200px;}
  75%  {background-color:green; left:0px; top:200px;}
  100% {background-color:red; left:0px; top:0px;} */
 
/* 0%   {box-shadow: 0  0 5px 10px rgb(255, 253, 147);} */
  /* 25%  {box-shadow: 0  0 5px 10px blue;} */
  25%  {box-shadow: 0  0 3px  5px rgb(3, 228, 3);}
  /* 75%  {box-shadow: 0  0 1px  2px blue;} */
  /* 100% {box-shadow: 0  0 10px 15px rgb(7, 172, 43);} */
 
  


}


.anim-textbackaaaaa{
  /* padding: 1px; */
  /* animation-name: down2animation; */
  /* animation-duration: 1s;
  animation-iteration-count: infinite; */
  animation-name: animtextback ;
  animation-duration: 2s;
  animation-direction: reverse;  
    animation-iteration-count: infinite;
}

@keyframes animtextback {
  /* 0%   {background-color:red; left:0px; top:0px;}
  25%  {background-color:yellow; left:200px; top:0px;}
  50%  {background-color:blue; left:200px; top:200px;}
  75%  {background-color:green; left:0px; top:200px;}
  100% {background-color:red; left:0px; top:0px;} */
 
/* 0%   {box-shadow: 0  0 5px 10px rgb(255, 253, 147);} */
  /* 25%  {box-shadow: 0  0 5px 10px blue;} */
  25%  {color: rgb(1, 160, 1);}
  /* 25%  {color: 0  0 3px  5px rgb(3, 228, 3);} */
  75%  {color: rgb(203, 255, 155);}
  /* 100% {box-shadow: 0  0 10px 15px rgb(7, 172, 43);} */
 
  


}


/* ------------------------------------------------------------------ */


.animaaaaa{
  padding: 1px;
  /* animation-name: down2animation; */
  /* animation-duration: 1s;
  animation-iteration-count: infinite; */
  animation-name: animkf;
  animation-duration: 4s;
  animation-direction: reverse;  
    animation-iteration-count: infinite;
}
 
@keyframes animkf {
  /* 0%   {background-color:red; left:0px; top:0px;}
  25%  {background-color:yellow; left:200px; top:0px;}
  50%  {background-color:blue; left:200px; top:200px;}
  75%  {background-color:green; left:0px; top:200px;}
  100% {background-color:red; left:0px; top:0px;} */


  /* 0%   {background-color:red; left:0px; top:0px;} */
  50%  {background-color:yellow;border-radius: 4px;color:red;font-weight: bold }
  /* 50%  {background-color:blue; left:200px; top:200px;} */
  /* 75%  {background-color:green; left:0px; top:200px;} */
  /* 50% {background-color:red; } */




}


.animbgcolor2  {
  background-color: #3c50ff;
  /* background-color:  #3c50ff   ; */
  /* background-size: 400% 400%; */
  /* animation: gradient2 5s ease infinite; */
  /* height: 100vh; */
}
.animbgcolor {
  background-color: #3c50ff;
  /* background: linear-gradient(-45deg, #3c50ff, #0456a3, #6589ff, #ddf864); */
  /* background-size: 400% 400%; */
  /* animation: gradient 5s ease infinite; */
  /* height: 100vh; */
}
@keyframes gradient {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}


</style>

<style>
  .unit {
    border: 2px solid black;
    border-radius: 0px 8px 8px 8px;
    cursor: cell;
    display: flex;
    flex-direction: column;
    padding: 5px;
    text-align: center;
    position: relative;
    min-height: 68px;
  }

  .unitin{
 font-size: 1px;
    
  }
  .unitin:hover{
    font-size: 22px;
    
  }
  .unit:hover {
    background-color: black;
    color: white;
    z-index: 1;
    animation: scale 0.5s ease-in-out forwards;
  }
  
  
  @keyframes scale {
    0% {
      transform: scale(1, 1);
    }
    10% {
      transform: scale(1.1, 0.9);
      box-shadow: rgba(0, 0, 0, 0.3) 1px 2px 3px 1px;
    }
    30% {
      transform: scale(1.9, 2.1);
      box-shadow: rgba(0, 0, 0, 0.1) 1px 1px 3px 1px;
    }
    50% {
      transform: scale(2, 2);
    }
    57% {
      transform: scale(2, 2);
      box-shadow: rgba(0, 0, 0, 0.1) 1px 2px 4px 1px;
    }
    64% {
      transform: scale(2, 2);
    }
    100% {
      transform: scale(2, 2);
      box-shadow: rgba(0, 0, 0, 0.2) 1px 2px 7px 1px;
    }
  }
  
  </style>


{{-- news --}}
<style>
  body{
    height: 1700px;
  }
  .news {
    width: 160px
}

.news-scroll a {
    text-decoration: none
}

.dot {
    height: 6px;
    width: 6px;
    margin-left: 3px;
    margin-right: 3px;
    margin-top: 2px !important;
    background-color: rgb(207, 23, 23);
    border-radius: 50%;
    display: inline-block
}
</style>
  
  <style>
    .fixed-down {
  position: fixed;
  bottom: 0;
  right: 0;
  width: 100%;
  border: 1px solid #73AD21;
}
  </style>
  <style>
    .dropdown {
      position: relative;
      display: inline-block;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      padding: 12px 16px;
      z-index: 1;
      min-height: 200px
    }
    
    .dropdown:hover .dropdown-content {
      display: block;
    }
    </style> 
    
  
    {{--  Pure css click dropdown menu  --}}
    <style>
/* 
html, body {
  padding:0;
  margin:0;
  background:rgb(199, 196, 196);
  height:140%;
  width:100%;
  
} */
.c {
  display: flex;
  align-items: center;
  justify-content: center;
  height:100%;
  width:100%;
}
.dd {
  z-index:1;
  position:relative;
  display: inline-block;
}
 
.dd input:checked:after {
  transform: scaleX(1);
  -webkit-transform: scaleX(1);
}
.dd input:checked ~ .dd-c {
  transform: scaleY(1);
  -webkit-transform: scaleY(1);
}
.dd-a span {
  color:#C63D0F;
}
.dd-c{
  display:block;
  position: absolute;
  background:white;
  height:auto;
  transform: scaleY(0);
  transform-origin: top left;
  transition-duration: 0.2s;
  -webkit-transform: scaleY(0);
  -webkit-transform-origin: top left;
  -webkit-transition-duration: 0.2s;
}
.dd-c ul {
  margin:0;
  padding:0;
  list-style-type: none;
}
.dd-c li {
  margin-botom:5px;
  word-break: keep-all;
  white-space:nowrap;
  display:block;
  position:relative;
}
a {
  display:block;
  position:relative;
  text-decoration: none;
  padding:5px;
  /* background:white;
  color:#C63D0F; */
}
a:before {
  z-index:0;
  content:"";
  position:absolute;
  display:block;
  height:100%;
  width:100%;
  -webkit-transition-duration: 0.2s;
  transition-duration: 0.2s;
  transform-origin:top left;
  -webkit-transform-origin:top left;
  /* background:#C63D0F; */
  top:0;
  left:0;
  transform: scaleX(0);
  -webkit-transform: scaleX(0);
}
a span {
  display:block;
  position:relative;
  -webkit-transition-duration: 0.2s;
  transition-duration: 0.2s;
}
a:hover:before {
  transform:scaleX(1);
  -webkit-transform:scaleX(1);
}
a:hover span {
  /* color:white; */
}

  </style>
  {{--  <div class="c">
    <!-- The dropdown starts here... -->
    <div class="dd">
      <div class="dd-a"><span>Dropdown menu</span></div>
      <input type="checkbox">
      <div class="dd-c">
        <ul>
          <li><a href="#"><span>Link</span></a></li>
          <li><a href="#"><span>A somewhat longer link to expand the menu further.</span></a></li>
          <li><a href="#"><span>Link</span></a></li>
          <li><a href="#"><span>Link</span></a></li>
        </ul>
      </div>
    </div>
    <!-- ...and ends here. -->
  </div>  --}}




  <style>


.Shine:after {
	content:'';
  /* top:0; */
	transform:translateX(300%)  ;
	width:15px;
  opacity: .6;
	height:45px;
	position: absolute;
	z-index:1;
	animation: slide 7s infinite;
	 
  /* 
  CSS Gradient - complete browser support from http://www.colorzilla.com/gradient-editor/ 
  */
  background: -moz-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,0.8) 50%, rgba(128,186,232,0) 99%, rgba(125,185,232,0) 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, right top, color-stop(0%,rgba(255,255,255,0)), color-stop(50%,rgba(255,255,255,0.8)), color-stop(99%,rgba(128,186,232,0)), color-stop(100%,rgba(125,185,232,0))); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,0.8) 50%,rgba(128,186,232,0) 99%,rgba(125,185,232,0) 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,0.8) 50%,rgba(128,186,232,0) 99%,rgba(125,185,232,0) 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(left, rgba(255,255,255,0) 0%,rgba(255,255,255,0.8) 50%,rgba(128,186,232,0) 99%,rgba(125,185,232,0) 100%); /* IE10+ */
	background: linear-gradient(to right, rgba(255,255,255,0) 0%,rgba(255,255,255,0.8) 50%,rgba(128,186,232,0) 99%,rgba(125,185,232,0) 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#00ffffff', endColorstr='#007db9e8',GradientType=1 ); /* IE6-9 */
}

/* animation */

@keyframes slide {
	0% {transform:translateX(-400%);}
	50% {transform:translateX(100%);}	
  100% {transform:translateX(-400%);}
  /* 100% {transform:translateX(-100%);}
  0% {transform:translateX(400%);} */
}





  </style>

{{-- dropdown --}}
 
  <style>
/* body {
  color: #000000;
  font-family: Sans-Serif;
  padding: 30px;
  background-color: #f6f6f6;
}

a {
  text-decoration: none;
  color: #000000;
}

a:hover {
  color: #222222
} */

/* Dropdown */

.dropdown {
  display: inline-block;
  position: relative;
}

.dd-button {
  display: inline-block;
  border: 1px solid gray;
  border-radius: 4px;
  padding: 10px 30px 10px 20px;
  background-color: #ffffff;
  cursor: pointer;
  white-space: nowrap;
}

.dd-button:after {
  content: '';
  position: absolute;
  top: 50%;
  right: 15px;
  transform: translateY(-50%);
  width: 0; 
  height: 0; 
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 5px solid black;
}

.dd-button:hover {
  background-color: #eeeeee;
}


.dd-input {
  display: none;
}

.dd-menu {
  position: absolute;
  top: 100%;
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 0;
  margin: 2px 0 0 0;
  box-shadow: 0 0 6px 0 rgba(0,0,0,0.1);
  background-color: #ffffff;
  list-style-type: none;
}

.dd-input + .dd-menu {
  display: none;
} 

.dd-input:checked + .dd-menu {
  display: block;
} 

.dd-menu li {
  padding: 10px 20px;
  cursor: pointer;
  white-space: nowrap;
}

.dd-menu li:hover {
  background-color: #f6f6f6;
}

.dd-menu li a {
  display: block;
  margin: -10px -20px;
  padding: 10px 20px;
}

.dd-menu li.divider{
  padding: 0;
  border-bottom: 1px solid #cccccc;
}
  </style>{{--end dropdown --}}