@extends('layouts.app') 


@section('content')
<div class="flex justify-center">
    @livewire('randlistwire')
</div>



<div class="flex justify-center">
    @livewire('admin.class-sys.class-syswire')
</div>

 


@endsection