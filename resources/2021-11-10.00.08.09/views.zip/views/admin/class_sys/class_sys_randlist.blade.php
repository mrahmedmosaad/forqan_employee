<p class="bg-danger">class_sys_randlist
<br>

@if (isset($studentsidarray) )
   {{-- {{ $studentsidarray[0]  }}  --}}
@endif
{{-- {{ $studentsidarray }} 
{{ print_r($studentsidarray) }} --}}
</p>