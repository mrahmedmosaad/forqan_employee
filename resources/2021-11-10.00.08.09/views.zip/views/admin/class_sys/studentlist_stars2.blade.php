@if ($starnumber==3 ||$starnumber==4)
<img src="good_job.png" alt=""  
class="hvr-buzz-out animate__animated  animate__flipInY"
style="position: absolute  ;width:44px ;left:25px;top:6px;">
 {{-- z-index:9999 --}}

@endif
{{-- animate__rubberBand --}}
@if ($starnumber==5)
<img src="excellent.png" alt="" 

{{-- animate__flipInY--}}
class="hvr-buzz-out animate__animated   animate__flip"
style="position: absolute  ;width:54px ;left:25px;top:1px;">

@endif
