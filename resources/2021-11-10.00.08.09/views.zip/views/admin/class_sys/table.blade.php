
<div class="text-center">
<label for="today_only ">today_only</label>

<input type="checkbox" name="" id="today_only" wire:model='today_only' value="1">
{{-- {{ $today_only }} --}}
 <table class="table table-light">
     <thead>
         <th>
             day/period
         </th>
         @for ($ih = 1; $ih <= 6; $ih++)
         <th>
             @include('admin.class_sys.table-head')  
         </th>
         @if ($ih==3)
         <th> break</th>
@endif
         @endfor
     </thead>
     
     <tbody>

        @if ($today_only==1)
        <?php
$iday = $day_today;
        ?>

             @include('admin.class_sys.table-day') 
        @else
            
      
            @for ($iday = 1; $iday <= 5; $iday++)
                           @include('admin.class_sys.table-day')  
            @endfor
              @endif
     </tbody>

 </table>
====================
</div>
