@extends('layouts.app') 


@section('content')
{{-- admin.class_sys.class_sys_report --}}
@livewire('admin.class-sys.class-sys-reportwire')





@endsection