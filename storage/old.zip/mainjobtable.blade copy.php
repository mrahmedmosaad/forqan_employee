p{{$test1}}

@include('employeeadmin.employeenew.main.modalsm2')


    
    <div class="dropdown">
      <button class="dropbtn">Dropdown</button>
      <div class="dropdown-content">

        <button type="submit">yes</button> <br>
        <button type="submit">no</button>
        <a href="#">Link 1</a>
        <a href="#">Link 2</a>
        <a href="#">Link 3</a>
      </div>
    </div>







<table class="table rtl text-right table-hover table-inverse table-responsive">
    <thead class="thead-inverse">
      <tr>
        <th>#</th>
        <th>السنة</th>
        <th>الوظيفة</th>
         <th>التخصص</th>
        <th>المدرسة</th>
        <th>المرحلة</th>
        <th> حالة العمل</th>
         <th>تاريخ المباشرة من</th>
        <th>الي</th>
        <th>ملاحظات</th>
        <th> ملف المباشرة </th>
        <th>ملف النقل او التكليف</th>
        
      </tr>
      </thead>
      <tbody>
   @if ($datajob!==[] )
       
  
       @foreach ($datajob as $item)
         <tr>
                   <td scope="row">{{ $counter++}}</td>
                   <td> {!! $item->jobyear !!}</td>
                   <td> {!! $item->job !!}</td>
                  
                   <td> {!! $item->job_division !!}</td>
                   <td> {!! $item->school !!}</td>
                   <td> {!! $item->stage !!}</td>
                   <td> {!! $item->job_status !!}</td>
            
                   <td> {!! $item->jobstartdate !!}</td>
                   <td> {!! $item->jobfinishdate !!}</td>
                   <td> {!! $item->notesjob !!}</td>
                   <td> 





                     

<img  class="svgsm" src="storage/icons/upload{{(Storage::disk('public')->exists('images/'.$userid.'/job'.$item->id.'.png'))?'2':'1'}}.svg" alt=""class="btn btn-primary" data-toggle="modal" data-target="#myModalfileimgjob{{$item->id}}" data-backdrop="static" data-keyboard="false">
    <!-- Central Modal Small -->
    <div wire:ignore class="modal fade" id="myModalfileimgjob{{$item->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-sm" role="document">
        <!--Content-->
        <div class="modal-content">
          <!--Header-->
          {{-- <div class="modal-header">
            <h4 class="modal-title w-100" id="myModalfileimgjob{{$item->id}}">Modal title</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div> --}}
          <!--Body--> 
          <div class="modal-body" >

            <input type="file" name="" id="fileimgjob{{$item->id}}" hidden  wire:model='img1'>

            <img class="svgsm" src="storage/icons/fileaddimg.svg" alt="edit"     onclick="fileimgjob{{$item->id}}.click()">
            <img class="svgsm" src="storage/icons/savedata.svg" alt="edit"      wire:click='uploadimg({{$item->id}})'>
            <hr>
            
            <img class="svgvsm" src="storage/icons/view.svg" alt="edit"     onClick="window.open('storage/images/{{$userid}}/job{{$item->id}}.png');"  >
                                
           
            <img class="svgvsm" src="storage/icons/delete.svg" alt="edit"     wire:click='deleteimg({{$item->id}})'  >
          


            
          </div>
          <!--Footer-->
          <div class="modal-footer"> 
            <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>fffffffffffff
            <button type="button" class="btn btn-primary btn-sm">Save changes</button>
          </div>
        </div>
        <!--/.Content-->
      </div>
    </div>
    <!-- Central Modal Small -->
   





















                       
                  
       
{{-- wire:click='SETJOBID({{$item->id}})' --}}
                {{-- <img class="svgvsm" src="storage/icons/delete.svg" alt="DELETE"   wire:click='SETJOBID({{$item->id}})'  onclick="return confirm('Are you sure you want to remove the user from this group?');"  > --}}
                {{-- <img class="svgvsm" src="storage/icons/delete.svg" alt="DELETE"  wire:ignore  data-toggle="modal" data-target="#centralModalSm"  wire:click='SETJOBID({{$item->id}})'   > --}}


                   
                  
{{-- yyy --}}

                   </td>
  
                   <td>
                    {{-- <button    class="btn btn-primary" href="#" role="button" wire:click='editjob({{$item->id}})'>edit</button> --}}
                  
                    <img class="svgvsm" src="storage/icons/edit.svg" alt="edit"    wire:click='editjob({{$item->id}})' >

                  
                  
                  </td>
                   <td>
                      {{-- <button    class="btn btn-danger" href="#" role="button" wire:click='deletejob({{$item->id}})'>delete</button> --}}
  <img class="svgvsm" src="storage/icons/delete.svg" alt="edit"     wire:click='deleteimg({{$item->id}})'  >
  {{-- if (confirm("Do you really want to delete your profile?")) {} --}}
      {{-- onclick="return confirm('Are you sure you want to remove the user from this group?');" --}}

                  <button id="delfile{{$item->id}}" hidden >delete</button>
                 
    
                  
                  </td>
         
  
                  {{-- <td> {!! $datajob['year']           !!}</td>
                  <td> {!! $datajob['jobname']            !!}</td>
                  <td> {!! $datajob['job_division']   !!}</td>  
                  <td> {!! $datajob['school']         !!}</td>  
                  <td> {!! $datajob['stage']          !!}</td>  
                  <td> {!! $datajob['status']         !!}</td>    
                  <td> {!! $datajob['jobstartdate']   !!}</td>          
                  <td> {!! $datajob['jobfinishdate']  !!}</td>           
                  <td> {!! $datajob['notesjob']       !!}</td>       --}}
  
  
           
        </tr>
           
        @endforeach  
       
   @endif
   <tr>
    {{-- <th>#</th>
    <th>السنة</th>
    <th>الوظيفة</th>
     <th>التخصص</th>
    <th>المدرسة</th>
    <th>المرحلة</th>
    <th> حالة العمل</th>
     <th>تاريخ المباشرة من</th>
  <th>الي</th>
  <th>ملاحظات</th>
  <th> ملف المباشرة </th>
  <th>ملف النقل او التكليف</th> --}}
    
  </tr>
   <tr>
     {{-- edit section --}}
    <td scope="row"></td>
    <td>
  
        <input  type="text"  class={{ $inputClass }} autocomplete="off" 	  wire:model.lazy='jobyear' />		
        @error('jobyear') <small class="text-danger">{{ $message }}</small> @enderror
       
    </td>
    <td>
      <input   type="text" class={{ $inputClass }}  autocomplete="off"  required 	  wire:model.lazy='jobname' />		
      @error('jobname') <small class="text-danger">{{ $message }}</small> @enderror
   
    <td>
   
      <input type="text"  class={{ $inputClass }}  autocomplete="off"  required 	  wire:model.lazy='job_division' />		
      @error('job_division') <small class="text-danger">{{ $message }}</small> @enderror
     
    </td>
    
    <td>
      <input class={{$inputClass}} type="text" name="school"  	  wire:model.lazy='school' />		
                
      @error('school') <small class="text-danger">{{ $message }}</small> @enderror
  
    </td>
    
    <td>
      <input class={{$inputClass}} type="text"   name="stage"  	  wire:model.lazy='stage' />		
                
      @error('stage') <small class="text-danger">{{ $message }}</small> @enderror
  
    </td>
    
    <td>{{$job_status}}
      <select   class={{$inputClass}}  
      wire:model.lazy='job_status' 
      >
      @foreach ($listall->where("listdev_id","22") as $item)
      <option>{{ $item->list_item_ar }}</option>
      @endforeach
          {{-- <option>اساسى</option>
          <option> منقول</option>
          <option>مكلف</option>
          <option>  تم النقل</option>
          <option>ترك العمل   لاسباب اخري</option> --}}
  
        </select>
  
    </td>
    
    <td>
      <input class={{$inputClass}} type="date"   name="jobstartdate"  	  wire:model.lazy='jobstartdate' />		
                
      @error('jobstartdate') <small class="text-danger">{{ $message }}</small> @enderror
  
    </td>
    
    <td>
      <input class={{$inputClass}} type="date"   name="jobfinishdate"  	  wire:model.lazy='jobfinishdate' />		
                
      @error('jobfinishdate') <small class="text-danger">{{ $message }}</small> @enderror
  
    </td>
    <td>
        <input class={{$inputClass}} type="text"      	  wire:model.lazy='notesjob' />		
                
        @error('notesjob') <small class="text-danger">{{ $message }}</small> @enderror    


    </td>
  
    <td>
      {{-- <span class="fa  fa-cloud-arrow-up"></span>
      <input class={{ $inputClass }} type="file"  accept="image/png, image/gif, image/jpeg"  name="jobfile1"  >
      @error('jobfile1') <small class="text-danger">{{ $message }}</small> @enderror --}}
  
    </td>
    
    <td>
      {{-- <input class={{ $inputClass }} type="file"  accept="image/png, image/gif, image/jpeg"  name="jobfile2"  >
      @error('jobfile2') <small class="text-danger">{{ $message }}</small> @enderror
   --}}
    
   <img class="svgvsm" src="storage/icons/savedata.svg" alt="edit"    wire:click='insrteditjob({{ ($jobeditmood==0)?$userid:$jobid}})'>
</td>
  
    <td>
    
  <img class="svgvsm" src="storage/icons/cancel.svg" alt="edit"    wire:click='jobcleartxt()'>
    </td>
   
   
   </tr>
  
          
      </tbody>
  </table>
  jobeditmood={{$jobeditmood}}
  