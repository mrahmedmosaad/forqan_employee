{{-- job --}}

{{-- بيانات خاصة بدولة القدوم --}}
<div class="container-fluid text-justify" dir="rtl">
  <div class="card bg-light mb-0">
    <div class="card-header p-1"> بيانات العمل
    </div>
    <div class="card-body">
      <div class="row">

        <div class={{$class}}>
          {{-- -------------------------------------- --}}

          <div class="form-group ">
            <label>job</label>
            <input class={{$inputClass}} type="text" name="job" id="job" autocomplete="off" value="" required 	  wire:model.lazy='job' />		


            @error('job') <small class="text-danger">{{ $message }}</small> @enderror
          </div>


          {{-- -------------------------------------- --}}

        </div>
        <div class={{$class}}>
          {{-- -------------------------------------- --}}

          <div class="form-group">
            <label> year</label>
            <input class={{$inputClass}} type="text" name="year" id="year" autocomplete="off" value="" 	  wire:model.lazy='year' />		

            @error('year') <small class="text-danger">{{ $message }}</small> @enderror
          </div>
          {{-- -------------------------------------- --}}
        </div>
        <div class={{$class}}>
          {{-- -------------------------------------- --}}
          <label> school</label>
          <input class={{$inputClass}} type="text" id="school" name="school" value="" 	  wire:model.lazy='school' />		

          @error('school') <small class="text-danger">{{ $message }}</small> @enderror
          {{-- -------------------------------------- --}}
        </div>

        <div class={{$class}}>
          {{-- -------------------------------------- --}}
          <label> stage</label>
          <input class={{$inputClass}} type="text" id="stage" name="stage" value="" 	  wire:model.lazy='stage' />		

          @error('stage') <small class="text-danger">{{ $message }}</small> @enderror
          {{-- -------------------------------------- --}}
        </div>

        <div class={{$class}}>
          {{-- -------------------------------------- --}}
          <label> notes</label>
          <input class={{$inputClass}} type="text" id="notesjob" name="notesjob" value="" 	  wire:model.lazy='notesjob' />		

          @error('notesjob') <small class="text-danger">{{ $message }}</small> @enderror
          {{-- -------------------------------------- --}}
        </div>



      </div>
    </div>
  </div>
</div>


{{--

<div class="form-group">
  <label for="">job</label>
  <input type="text" class="form-control" name="job" id="job" aria-describedby="helpId" placeholder="">
  <small id="helpId" class="form-text text-muted">Help text</small>
</div>

<div class="form-group">
  <label for="">year</label>
  <input type="text" class="form-control" name="year" id="year" aria-describedby="helpId" placeholder="">
  <small id="helpId" class="form-text text-muted">Help text</small>
</div>

<div class="form-group">
  <label for="">school</label>
  <input type="text" class="form-control" name="school" id="school" aria-describedby="helpId" placeholder="">
  <small id="helpId" class="form-text text-muted">Help text</small>
</div>

<div class="form-group">
  <label for="">stage</label>
  <input type="text" class="form-control" name="stage" id="stage" aria-describedby="helpId" placeholder="">
  <small id="helpId" class="form-text text-muted">Help text</small>
</div>

<div class="form-group">
  <label for="">notes</label>
  <input type="text" class="form-control" name="notes" id="notes" aria-describedby="helpId" placeholder="">
  <small id="helpId" class="form-text text-muted">Help text</small>
</div>


--}}